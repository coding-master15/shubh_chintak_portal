<div class="navbar">
    <div>
        <a href="chooser"><img src="/img/yoco/demo/cropped-yoco-logo-white-background.jpg" style="max-height: 50px;"/></a>
        <p class="vertical-center">SWAG</p>
    </div>
</div>

